$(function() {
    $.fn.autoClear = function () {
        
        $(this).each(function() {
            $(this).data("autoclear", $(this).attr("value"));
        });
        $(this)
            .bind('focus', function() {   
                if ($(this).attr("value") == $(this).data("autoclear")) {
                    $(this).attr("value", "").addClass('autoclear-normalcolor');
                }
            })
            .bind('blur', function() { 
                if ($(this).attr("value") == "") {
                    $(this).attr("value", $(this).data("autoclear")).removeClass('autoclear-normalcolor');
                }
            });
        return $(this);
    }
});

$(function() { 
    $('.styled-input').autoClear();
});

$(window).load(function() {
    $(".main-page-slider ul li").css({
        height: $(".main-page-slider ul li").find("img").height()+20
    })
    $(".main-page-slider ul").bxSlider({
        onSliderLoad: function(){
            $(".bx-pager").after("<a href='#' class='hideSlider'>Скрыть слайдер</a>");
        }
    });
    $(document).on("click", ".hideSlider", function(){
        $(".main-page-slider").slideUp();
    })
    //checkbox
    $('.checkBox').click(function() {
        $(this).parent().parent().toggleClass('active');
    });
    //end checkbox
});